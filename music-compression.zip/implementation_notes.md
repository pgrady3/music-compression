# Implementation Scratch Pad

## Bit rate and segment length for out algorithm

If we go with 128 kbps data. 16 second is the length we should aim for. We have 128 * 1024 * 16 data points. If we consider 32 bit floating point number, it gives us 65536 points in the data
