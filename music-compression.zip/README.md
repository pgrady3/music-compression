# music-compression

Steps to install and run

1. Download fma_xs from OneDrive, extract to data/fma_xs
2. Convert data to torch tensors for faster loading

```python utils/io.py```

3.